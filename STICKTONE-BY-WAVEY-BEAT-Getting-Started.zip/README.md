# StickTone by Wavey Beat

StickTone by Wavey Beat is an original cross-platform drum-instrument prototype inspired by the workflow of classic drum-production plugins. It is not affiliated with or a copy of Toontrack EZdrummer.

## Current prototype

- JUCE plugin target configured for VST3, Audio Unit (macOS), and Standalone.
- MIDI note input for kick, snare, closed hat, open hat, and crash.
- Click-to-audition kit controls.
- Per-piece level controls.
- Simple built-in 16-step groove audition.
- Basic processor state serialization.

**Important:** the current voice generator is procedural synthesis, not the final sample-based engine. The sample loader, full mixer, groove library, Tap2Find search, Song Creator, MIDI file export, and preset file dialogs are follow-on milestones. Controls marked “next milestone” are intentionally disabled.

## Requirements

- CMake 3.22+
- A C++17 toolchain:
  - Windows: Visual Studio 2022 with C++ desktop workload
  - macOS: Xcode command-line tools and a supported Xcode version
- JUCE source checkout

## Get JUCE

From the `StickTone` directory:

```bash
git clone https://github.com/juce-framework/JUCE.git JUCE
```

For reproducible builds, pin the JUCE checkout to a tested release tag rather than tracking `master`.

## Build on Windows

Open a Developer PowerShell for Visual Studio 2022:

```powershell
cmake -S . -B build -A x64
cmake --build build --config Release
```

## Build on macOS

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DCMAKE_OSX_ARCHITECTURES=arm64
cmake --build build --config Release
```

For Intel Macs, use `-DCMAKE_OSX_ARCHITECTURES=x86_64`. To produce a universal binary, configure a universal architecture build supported by your toolchain and JUCE dependencies.

## MIDI mapping

| Instrument | MIDI note | GM-style name |
|---|---:|---|
| Kick | 36 | Bass Drum 1 |
| Snare | 38 | Acoustic Snare |
| Closed Hat | 42 | Closed Hi-Hat |
| Open Hat | 46 | Open Hi-Hat |
| Crash | 49 | Crash Cymbal 1 |

## Roadmap

1. Replace procedural voices with a sample-backed engine (velocity layers, round robins, choke groups).
2. Add independent close/overhead/room buses, pan, effects, bleed and ambience.
3. Add a groove database and Standard MIDI File import/export.
4. Add Tap2Find using onset-grid / rhythm-feature matching.
5. Add arrangement timeline with intro, verse, chorus, fills and ending.
6. Add project and kit preset save/load with versioned schema.
7. Add automated audio tests, plugin-host validation, packaging and code signing.

## Architecture notes

The audio callback must remain real-time safe. Production sample loading should happen off the audio thread; voices should use immutable loaded sample data; parameter changes should be atomic or delivered through lock-free state. Never load files, allocate large objects, or block inside `processBlock`.
