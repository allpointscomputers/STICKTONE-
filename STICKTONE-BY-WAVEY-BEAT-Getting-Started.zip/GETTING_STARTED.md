# STICKTONE BY WAVEY BEAT — Getting Started

This is the existing StickTone prototype source project. It has **not been verified as built** on your computer. Treat it as a starting point, not a finished commercial product.

## First milestone

1. Install Git and CMake.
2. Install a C++ build toolchain for your operating system.
3. Obtain JUCE and place its folder at `JUCE/` in this project, unless the project's CMake configuration specifies another supported JUCE location.
4. Open a terminal in this project folder.
5. Configure and build with the commands below.
6. Share any errors with Codex or ChatGPT so they can be diagnosed.

## Windows prerequisites

- Visual Studio 2022 with the **Desktop development with C++** workload, including a Windows SDK.
- CMake (current stable version).
- Git.
- JUCE source checkout compatible with the project's CMake configuration.

After installing prerequisites, open **Developer PowerShell for Visual Studio**, navigate to this project directory, then run:

```powershell
cmake -S . -B build
cmake --build build --config Release
```

If configuration says JUCE cannot be found, check the project README/CMakeLists and put the JUCE checkout in the expected `JUCE/` directory. Then rerun configuration.

## macOS prerequisites

- Xcode from the Mac App Store, then open Xcode once and accept its license if prompted.
- Xcode Command Line Tools.
- CMake.
- Git.
- JUCE source checkout compatible with the project's CMake configuration.

Open Terminal in this project directory and run:

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release
```

If configuration says JUCE cannot be found, check the project README/CMakeLists and put the JUCE checkout in the expected `JUCE/` directory. Then rerun configuration.

## Important notes

- The initial prototype uses procedural/synthesized drum sounds. It does not include a professionally recorded acoustic drum library.
- Windows builds cannot verify macOS AU builds. AU builds and validation require macOS and appropriate Apple tooling.
- A successful CMake configure is not the same as a successful build. A successful build is not the same as a verified DAW/plugin test.
- Do not run unknown scripts or grant elevated permissions just to make a build pass.
- Keep a backup of the original project before major changes.

## Next task for Codex

Open this folder in Codex and give it the master implementation prompt. Ask it to inspect the existing files first, run a baseline build, report the exact commands/results, and then implement the first compiling vertical slice. Do not let it claim success without actual build and test evidence.
